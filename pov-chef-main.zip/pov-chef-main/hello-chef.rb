file '/Users/sai.linnthu/pov-chef/hellocloudy.md' do
  content 'Hello, Cloudy version 1 - this file is created by chef.!'
end